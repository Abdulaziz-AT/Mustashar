<?php
session_start();
require_once 'database.php'; // Include your database connection file

// Check if required POST data is received
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['consultant_id'], $_POST['user_id'], $_POST['rating'])) {
    // Get the values from the POST request
    $consultantId = $_POST['consultant_id'];
    $userId = $_POST['user_id'];
    $rating = $_POST['rating'];

    // Validate rating
    if ($rating < 1 || $rating > 5) {
        echo json_encode(['error' => 'Please provide a rating between 1 and 5.']);
        exit;
    }

    try {
        // Insert the rating into the database
        $query = "INSERT INTO consultant_ratings (consultant_id, user_id, rating) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iii", $consultantId, $userId, $rating);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(['success' => 'Rating submitted successfully']);
        } else {
            echo json_encode(['error' => 'Error submitting your rating. Please try again.']);
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    // Return an error if the required POST data is not received
    echo json_encode(['error' => 'Invalid input data']);
}
?>
