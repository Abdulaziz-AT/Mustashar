<?php
require_once 'database.php'; // Ensure the database connection file path is correct

$name = $_GET['name'] ?? ''; // Using null coalescing operator to handle unset input
$searchTerm = '%' . $name . '%';
$sql = $name ? "SELECT * FROM consultants WHERE first_name LIKE ? OR last_name LIKE ?" : "SELECT * FROM consultants";
$stmt = $conn->prepare($sql);

if ($name) {
    $stmt->bind_param('ss', $searchTerm, $searchTerm);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<a href="viewconsultant.php?id=' . $row['id'] . '" class="col-md-4 mb-4 consultant-card-link">';
        echo '<div class="consultant-card" data-category="' . strtolower(str_replace(' ', '', $row['field'])) . '">';
        echo '<img src="profile-icon.svg" class="img-fluid" alt="' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '">';
        echo '<div class="consultant-info">';
        echo '<h4>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</h4>';
        echo '<p>Field: ' . htmlspecialchars($row['field']) . '</p>';
        echo '<p>Experience: ' . htmlspecialchars($row['experience']) . ' years</p>';
        echo '<p>Bio: ' . htmlspecialchars($row['bio']) . '</p>';
        echo '</div></div></a>';
    }
} else {
    echo "<div class='alert alert-info'>No consultants found.</div>";
}

