<?php
session_start();
require_once "database.php";

// Capture the POST data from the frontend
$data = json_decode(file_get_contents("php://input"));

$email = $data->email;
$uid = $data->uid;

// Check if the user exists
$sql = "SELECT * FROM users WHERE email='$email' AND uid='$uid'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_array($result, MYSQLI_ASSOC);

if ($user) {
    // If user exists, log them in and create a session
    $_SESSION['user'] = 'yes';
    $_SESSION['user_id'] = $user['id'];  // Store user ID in session

    echo json_encode(['status' => 'success']);
} else {
    // If user doesn't exist, return status 'not_found'
    echo json_encode(['status' => 'not_found']);
}
?>
