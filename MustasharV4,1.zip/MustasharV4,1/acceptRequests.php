<?php
// acceptRequests.php
require 'database.php'; // Include database connection

$requestId = $_POST['request_id'];
// Update the request status in the database
$updateSQL = "UPDATE requests SET status = 'active' WHERE id = $requestId";
if (mysqli_query($conn, $updateSQL)) {
    // Send a success response
    echo json_encode(['success' => true]);
} else {
    // Send an error response
    echo json_encode(['success' => false, 'error' => 'Database update failed']);
}

// Close the database connection
mysqli_close($conn);
?>
