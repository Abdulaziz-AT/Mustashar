<?php
session_start();
include('database.php');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get data from the Google sign-in frontend
$data = json_decode(file_get_contents('php://input'), true);

if ($data && isset($data['email'], $data['name'], $data['uid'])) {
    $email = $data['email'];
    $name = $data['name'];
    $uid = $data['uid'];
    $provider = 'google';

    // Check if the user already exists
    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User already exists
        echo json_encode(['status' => 'exists']);
    } else {
        // Insert new user into the database
        $query = "INSERT INTO users (username, email, uid, provider) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ssss', $name, $email, $uid, $provider);

        if ($stmt->execute()) {
            // Optionally store user data in session
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;

            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database insertion failed: ' . $stmt->error]);
        }
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
}
?>
