<?php
// updateAvailability.php
session_start();
require 'database.php'; // Include your database connection

// Assuming you store the consultant's id in the session after login
$consultant_id = $_SESSION['consultant_id'];

if (isset($_POST['is_available'])) {
    $is_available = (int)$_POST['is_available'];

    // Update query
    $updateSQL = "UPDATE consultants SET is_available = $is_available WHERE id = $consultant_id";
    if (mysqli_query($conn, $updateSQL)) {
        // Return a JSON response
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Database update failed']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
}
?>
