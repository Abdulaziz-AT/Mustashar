<?php
session_start();
require 'database.php'; // Include your database connection

// Assuming you store the consultant's id in the session after login
$consultant_id = $_SESSION['consultant_id'];

$consultantSQL = "SELECT first_name, last_name, email, age, phone_number, field, experience, bio, is_available FROM consultants WHERE id = $consultant_id";

require_once "database.php";
$result = mysqli_query($conn, $consultantSQL);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $email = $row['email'];
    $age = $row['age'];
    $phone_number = $row['phone_number'];
    $field = $row['field'];
    $experience = $row['experience'];
    $bio = $row['bio'];
    $is_available = $row['is_available'];

}

// Fetch pending requests
$pendingRequestsSQL = "SELECT * FROM requests WHERE consultant_id = $consultant_id AND status = 'pending'";
$pendingRequestsResult = mysqli_query($conn, $pendingRequestsSQL);
$pendingRequests = mysqli_fetch_all($pendingRequestsResult, MYSQLI_ASSOC);

// Fetch active requests
$activeRequestsSQL = "SELECT * FROM requests WHERE consultant_id = $consultant_id AND status = 'active'";
$activeRequestsResult = mysqli_query($conn, $activeRequestsSQL);
$activeRequests = mysqli_fetch_all($activeRequestsResult, MYSQLI_ASSOC);




// Fetch user names for the pending requests
foreach ($pendingRequests as $index => $request) {
  $userId = $request['user_id'];
  $userSQL = "SELECT username FROM users WHERE id = $userId";
  $userResult = mysqli_query($conn, $userSQL);

  if ($userResult && mysqli_num_rows($userResult) > 0) {
      $user = mysqli_fetch_assoc($userResult);
      $pendingRequests[$index]['user_name'] = $user['username']; // Correctly assign using $index
  } else {
      $pendingRequests[$index]['user_name'] = "Unknown User"; // Fallback if user not found
  }
}


// Fetch user names for the active requests
foreach ($activeRequests as $index => $request) {
  $userId = $request['user_id'];
  $userSQL = "SELECT username FROM users WHERE id = $userId";
  $userResult = mysqli_query($conn, $userSQL);

  if ($userResult && mysqli_num_rows($userResult) > 0) {
      $user = mysqli_fetch_assoc($userResult);
      $activeRequests[$index]['user_name'] = $user['username']; // Correctly assign using $index
  } else {
      $activeRequests[$index]['user_name'] = "Unknown User"; // Fallback if user not found
  }
}




?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mustashar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
   <!-- Ajax -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


  <style>

    .profile-header-container {
      margin-top: 30px;
    }
    .profile-header {
      background-color: #ffffff;
      border: 1px solid #dddfe2;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .profile-img {
      width: 120px;
      height: 120px;
      object-fit: cover;
      border-radius: 50%;
      border: 3px solid #ffffff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .bio-text {
      font-size: 16px;
      color: #555;
    }
  </style>


</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="mustasharlogo.png" height="50px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="#" onclick="toggleAbout()">About/Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<!-- About Section -->
<div id="aboutSection" class="about-section">
    <div class="container mt-5">
      <h2 class="text-center mb-4">About Us</h2>
      <p class="lead">At Mustashar, we are more than just a consulting platform; we are a community dedicated to empowering developers
         at every stage of their journey. Our platform connects users with highly skilled consultants specializing in various software domains,
          including UX/UI design, requirement gathering, and quality assurance/control.
           We aim to provide a collaborative space where developers can seek guidance, share knowledge, and enhance their skills.
            Our commitment to fostering a vibrant ecosystem ensures that every developer has access to the expertise they need to 
            succeed in today's competitive landscape.</p>

      <h2 class="text-center mt-5 mb-4">Our Vision</h2>
      <p class="lead">We envision a future where every developer has seamless access to personalized consulting services that cater to their unique 
        challenges. Through Mustashar, we strive to break down barriers in the software development field, 
        enabling developers to connect with top-tier consultants effortlessly. 
        Our vision is to create an inclusive environment that promotes continuous learning, innovation, and collaboration. 
        By harnessing the collective knowledge and skills of our community, we aim to inspire developers to reach their 
        full potential and contribute meaningfully to the world of technology.</p>

      <h2 class="text-center mt-5 mb-4">Contact Us</h2>
      <p class="lead text-center">Email: <a href="mailto:abdulaziz.at00@gmail.com">abdulaziz.at00@gmail.com</a></p>
      <p class="lead text-center">WhatsApp: +966532606063</p>

      <div class="text-center">
        <p>Follow us:</p>
       <a href="#" class="text-white me-2"><i class="bi bi-facebook"></i></a>
       <a href="#" class="text-white me-2"><i class="bi bi-twitter"></i></a>
       <a href="#" class="text-white me-2"><i class="bi bi-linkedin"></i></a>
      </div>

      <div class="container text-center mt-5">
        <p class="lead">&copy; Mustashar 2024</p>
      </div>
    </div>
  </div>

  <script>
    function toggleAbout() {
      var aboutSection = document.getElementById('aboutSection');
      aboutSection.classList.toggle('show');
      var navbar = document.querySelector('.navbar');
      navbar.style.backgroundColor = aboutSection.classList.contains('show') ? '#343a40' : 'transparent'; // Change navbar background color based on section visibility
    }

  </script>

  <style>
    .navbar {
      transition: background-color 0.5s ease;
    }

    .about-section {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.5s ease;
      /* Smooth transition for max-height */
      background-color: #343a40;
      /* Match the background color of the navbar */
      color: #fff;
      /* Text color */
      padding: 20px;
    }

    .about-section.show {
      max-height: 1000px;
      /* Set to a large value to allow for dynamic content height */
    }
  </style>


  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">&copy; Mustashar</a>
      <form action="logout.php" method="post">
        <div class="navbar-nav">
          <button type="submit" class="btn btn-danger" style="border: 1px solid transparent; padding: 8px 16px;">Sign
            out</button>
        </div>
      </form>
    </div>
  </nav>

  
<!-- Consultant Dashboard Section -->
<div class="container mt-5">
  <h2 class="text-center mb-4">Consultant Dashboard</h2>

  <!-- Consultant Information -->
  <div class="container profile-header-container">
    <div class="profile-header text-center">
      <img src="profile-icon.svg" alt="Profile Image" class="profile-img mb-3">
      <h2><?= htmlspecialchars($first_name) . " " . htmlspecialchars($last_name); ?></h2>
      <p class="text-muted"><?= htmlspecialchars($field); ?></p>
      <div class="row justify-content-center">
        <div class="col-md-4">
          <ul class="list-group list-group-flush">
            <li class="list-group-item"><strong>Email:</strong> <?= htmlspecialchars($email); ?></li>
            <li class="list-group-item"><strong>Phone:</strong> <?= htmlspecialchars($phone_number); ?></li>
            <li class="list-group-item"><strong>Age:</strong> <?= htmlspecialchars($age); ?></li>
          </ul>
        </div>
        <div class="col-md-4">
          <ul class="list-group list-group-flush">
            <li class="list-group-item"><strong>Experience:</strong> <?= htmlspecialchars($experience); ?> years</li>
            <li class="list-group-item"><p class="bio-text"><strong>Bio:</strong> <?= nl2br(htmlspecialchars($bio)); ?></p></li>
          </ul>
        </div>
      </div>
      <button class="btn btn-primary" onclick="showEditConsultantProfileForm()"><i class="bi bi-pencil"></i> Edit Profile</button>
      <!-- Toggle Button for Availability -->
      <button id="availabilityToggle" class="btn btn-<?= $is_available ? 'success' : 'secondary'; ?>" onclick="toggleAvailability()">
        <?= $is_available ? 'Set as Not Available' : 'Set as Available'; ?>
      </button>
       <!-- Availability Icon -->
       <i id="availabilityIcon" class="bi <?= $is_available ? 'bi-check-circle-fill text-success' : 'bi-x-circle-fill text-danger'; ?>" style="font-size: 1.5rem; margin-left: 10px;"></i>
    </div>
  </div>
</div>


<script>
function toggleAvailability() {
    var button = document.getElementById('availabilityToggle');
    var icon = document.getElementById('availabilityIcon');
    var isAvailable = button.classList.contains('btn-success') ? 0 : 1; // Toggle the status

    // Update button and icon display
    if (isAvailable === 0) {
        button.classList.remove('btn-success');
        button.classList.add('btn-danger');
        button.textContent = 'Set as Available';
        icon.classList.remove('bi-check-circle-fill', 'text-success');
        icon.classList.add('bi-x-circle-fill', 'text-danger');
    } else {
        button.classList.remove('btn-danger');
        button.classList.add('btn-success');
        button.textContent = 'Set as Not Available';
        icon.classList.remove('bi-x-circle-fill', 'text-danger');
        icon.classList.add('bi-check-circle-fill', 'text-success');
    }

    // Send AJAX request to update availability in the database
    $.ajax({
    url: 'updateAvailability.php', // PHP script to handle the request
    type: 'POST',
    data: { is_available: isAvailable },
    dataType: 'json', // Expect a JSON response
    success: function(response) {
        if (response.success) {
            console.log('Availability updated successfully');
        } else {
            alert('Failed to update availability: ' + (response.error || 'Unknown error'));
        }
    },
    error: function() {
        alert('An error occurred while updating availability.');
    }
});


}

</script>


<!-- Edit Profile Modal -->
<div class="modal fade" id="editConsultantProfileModal" tabindex="-1" aria-labelledby="editConsultantProfileModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editConsultantProfileModalLabel">Edit Profile</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="updateProfile.php" method="post" enctype="multipart/form-data">
        <div class="modal-body">
          <!-- Profile Photo Upload -->
          <div class="mb-3">
            <label for="profilePhoto" class="form-label">Profile Photo</label>
            <input type="file" class="form-control" id="profilePhoto" name="profile_photo" accept="image/*">
          </div>
          <div class="text-center mb-3">
            <img id="previewPhoto" src="profile-icon.svg" alt="Profile Photo Preview" class="img-fluid rounded-circle" style="width: 100px; height: 100px;">
          </div>
          <div class="mb-3">
            <label for="bioInput" class="form-label">Bio</label>
            <textarea class="form-control" id="bioInput" name="bio" rows="3" required><?php echo htmlspecialchars($bio); ?></textarea>
          </div>
          <div class="mb-3">
            <label for="phoneInput" class="form-label">Phone Number</label>
            <input type="tel" class="form-control" id="phoneInput" name="phone_number" value="<?php echo htmlspecialchars($phone_number); ?>" required>
          </div>
          <div class="mb-3">
            <label for="bioInput" class="form-label">Age</label>
            <input type="number" class="form-control" id="phoneInput" name="age" value="<?php echo htmlspecialchars($age); ?>" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  function showEditConsultantProfileForm() {
    var editModal = new bootstrap.Modal(document.getElementById('editConsultantProfileModal'));
    editModal.show();
  }

  // Preview profile photo before uploading
  document.getElementById('profilePhoto').addEventListener('change', function(event) {
    var reader = new FileReader();
    reader.onload = function() {
      var preview = document.getElementById('previewPhoto');
      preview.src = reader.result;
    }
    reader.readAsDataURL(event.target.files[0]);
  });
</script>




<!-- Requests section -->

<div class="container mt-5">
    <h4 class="mt-4 text-center">Requests Overview</h4>

    <div class="accordion" id="requestsAccordion">
        <!-- Pending Requests Section -->
<div class="accordion-item border-0 shadow-sm mb-3">
    <h2 class="accordion-header" id="headingPending">
        <button class="accordion-button bg-secondary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePending" aria-expanded="true" aria-controls="collapsePending">
            Pending Requests
        </button>
    </h2>
    <div id="collapsePending" class="accordion-collapse collapse show" aria-labelledby="headingPending" data-bs-parent="#requestsAccordion">
        <div class="accordion-body bg-light">
            <?php if (!empty($pendingRequests)): ?>
                <div class="list-group">
                    <?php foreach ($pendingRequests as $request): ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center border-0 bg-white shadow-sm mb-2 rounded">
                            <div>
                                <p class="mb-1 fw-bold text-dark">Request from: <?= htmlspecialchars($request['user_name']); ?></p>
                                <small class="text-muted">Submitted on: <?= htmlspecialchars($request['created_at']); ?></small>
                            </div>
                            <button class="btn btn-success btn-sm" onclick="acceptRequest(<?= $request['id']; ?>)">Accept</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center text-muted">No pending requests.</div>
            <?php endif; ?>
        </div>
    </div>
</div>


<!-- Active Requests Section -->
<div class="accordion-item border-0 shadow-sm mb-3">
  <h2 class="accordion-header" id="headingActive">
    <button class="accordion-button collapsed bg-success text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#collapseActive" aria-expanded="false" aria-controls="collapseActive">
      Active Requests
    </button>
  </h2>
  <div id="collapseActive" class="accordion-collapse collapse" aria-labelledby="headingActive" data-bs-parent="#requestsAccordion">
    <div class="accordion-body bg-light">
      <?php if (!empty($activeRequests)): ?>
        <div class="list-group">
          <?php foreach ($activeRequests as $request): ?>
            <div class="list-group-item border-0 bg-white shadow-sm mb-2 rounded d-flex justify-content-between align-items-center">
              <div>
                <p class="mb-1 fw-bold text-dark">Request from: <?= htmlspecialchars($request['user_name']); ?></p>
                <small class="text-muted">Accepted on: <?= htmlspecialchars($request['created_at']); ?></small>
              </div>
              <button class="btn btn-primary btn-sm" onclick="openChat(<?= $request['consultant_id']; ?>, <?= $request['user_id']; ?>)">Chat</button>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="text-center text-muted">No active requests.</div>
      <?php endif; ?>
    </div>
  </div>
</div>



<script>
function acceptRequest(requestId) {
    // Send an AJAX request to accept the request
    $.ajax({
        url: 'acceptRequests.php', // The PHP script that will handle the request
        type: 'POST',
        data: { request_id: requestId },
        dataType: 'json', // Expect a JSON response
        success: function(response) {
            if (response.success) {
                alert("Request accepted successfully!");
                location.reload(); // Reload the page to update the request status
            } else {
                alert("There was an error accepting the request. Please try again.");
            }
        },
        error: function() {
            alert("An unexpected error occurred. Please try again.");
        }
    });
}

</script>

</div>
</div>



<!-- chatting interface under here-->




<!-- Chat Interface -->
<div id="chat-container" class="container my-4 p-3 border rounded shadow-sm" style="display: none;">
  <div id="message-list" class="p-3 mb-3" style="height: 300px; overflow-y: auto; background-color: #f8f9fa; border-radius: 5px;">
    <!-- Messages will be displayed here -->
  </div>
  <div class="input-group">
    <input type="text" id="message-input" class="form-control" placeholder="Type your message...">
    <button id="send-button" class="btn btn-dark">Send</button>
  </div>
</div>



<!-- Custom Styling for Chat Interface -->
<style>
  #chat-container {
    max-width: 600px;
    background-color: #ffffff;
  }
  #message-list {
    background-color: #f8f9fa;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .message {
    margin-bottom: 10px;
    padding: 8px 12px;
    border-radius: 10px;
    max-width: 70%;
    word-wrap: break-word;
  }
  .message.sent {
    background-color: #d1e7dd; /* Light green for sent messages */
    text-align: right;
    margin-left: auto;
  }
  .message.received {
    background-color: #e2e3e5; /* Light gray for received messages */
    text-align: left;
    margin-right: auto;
  }
  #message-input {
    border-radius: 0; /* Sleek design */
  }
  #send-button {
    border-radius: 0; /* Match the input field */
  }
  .sender-name {
  font-weight: bold;
  display: block; /* Ensures the name is on its own line */
  margin-bottom: 2px; /* Adds a small space between the name and message */
}

.message-text {
  margin-left: 10px; /* Add a small indentation for the message */
}

</style>


<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-database.js"></script>

  <script>
    // Your Firebase configuration
    const firebaseConfig = {
      apiKey: "AIzaSyDldngosQltlHmvQvgaodrMmFuNURElTmw",
      authDomain: "mustashar-8866c.firebaseapp.com",
      projectId: "mustashar-8866c",
      storageBucket: "mustashar-8866c.appspot.com",
      messagingSenderId: "152444754973",
      appId: "1:152444754973:web:01fd8a4a4d4ba0825dfaf4",
      measurementId: "G-C9MWBJ4BNX"
    };

    // Initialize Firebase
    try {
      firebase.initializeApp(firebaseConfig);
      const database = firebase.database();
      // Your code to interact with Firebase Realtime Database goes here
    } catch (error) {
      console.error("Error initializing Firebase:", error);
      // Display an error message to the user
    }
  


  // Get references to the DOM elements
const messageList = document.getElementById('message-list');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');

// Get a reference to the Firebase Realtime Database
const database = firebase.database();
const messagesRef = database.ref('messages');

// Function to send a message


const first_name = "<?= htmlspecialchars($first_name); ?>";
const last_name = "<?= htmlspecialchars($last_name); ?>";
const consultant_id = "<?php echo $consultant_id; ?>"; // Get consultant ID from PHP





function openChat(consultant_id, userId) {
  console.log("openChat function is called with consultant_id:", consultant_id, "and userId:", userId);

  // Generate a unique chat room ID using consultant and user IDs
  const chatRoomID = `chat_${consultant_id}_${userId}`;

  // Get a reference to the specific chat room in Firebase
  chatRoomRef = firebase.database().ref(`chatRooms/${chatRoomID}`);

  // Clear the message list when opening a new chat
  messageList.innerHTML = '';

  // Show the chat container
  document.getElementById('chat-container').style.display = 'block';

  // Start listening for new messages in this chat room
  chatRoomRef.on('child_added', (snapshot) => {
    const message = snapshot.val();
    appendMessage(message); // Append the new message to the chat interface
  });
}



function sendMessage() {
  const messageText = messageInput.value;
  if (messageText.trim() !== '') {
    const newMessageRef = chatRoomRef.push(); // Push to the specific chat room
    newMessageRef.set({
      sender: `${first_name} ${last_name} `, // Use the actual sender's name
      message: messageText,
      timestamp: Date.now()
    });
    messageInput.value = ''; // Clear the input field
  }
}

// Function to append a message
function appendMessage(message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message');

  // Create a name element
  const nameElement = document.createElement('strong');
  nameElement.textContent = `${message.sender}`;
  nameElement.classList.add('sender-name');

  // Create a message text element
  const messageTextElement = document.createElement('div');
  messageTextElement.textContent = message.message;
  messageTextElement.classList.add('message-text');

  // Append name and message text to the message element
  messageElement.appendChild(nameElement);
  messageElement.appendChild(messageTextElement);

  // Add styling
  messageElement.classList.add('p-2', 'mb-2', 'rounded', 'bg-light', 'border');

  // Append the message element to the message list
  messageList.appendChild(messageElement);

  // Scroll to the bottom to show the latest message
  messageList.scrollTop = messageList.scrollHeight;
}






// Attach event listener to the send button
sendButton.addEventListener('click', sendMessage);



</script>



  <!-- Footer -->
<footer class="bg-secondary text-white mt-0">
  <div class="bg-dark text-center py-3">
    <p class="mb-0">&copy; Mustashar 2024. All Rights Reserved.</p>
  </div>
</footer>


</body>
