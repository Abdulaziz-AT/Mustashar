<?php

session_start();
if (!isset($_SESSION["user"])) {
  header("Location: index.php");
}

$user_id = $_SESSION['user_id'];
$usernameSQL = "SELECT username, email, bio, phone_number FROM users WHERE id=$user_id";

require_once "database.php";
$result = mysqli_query($conn, $usernameSQL);
if (mysqli_num_rows($result) > 0) {
  $row = mysqli_fetch_assoc($result);
  $username = $row["username"];
  $email = $row["email"];
  $bio = $row["bio"];
  $phone_number = $row["phone_number"];
}

if (isset($_GET['id'])) 
    $consultantId = $_GET['id'];

    $consultantsSQL = "SELECT first_name, last_name, email, age, phone_number, field, experience, bio FROM consultants WHERE id=$consultantId";
    
    require_once "database.php";
    $result = mysqli_query($conn, $consultantsSQL);
    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $first_name = $row["first_name"];
      $last_name = $row["last_name"];
      $email = $row["email"];
      $age = $row["age"];
      $phone_number = $row["phone_number"];
      $field = $row["field"];
      $experience = $row["experience"];
      $bio = $row["bio"];
    }

// Check if there is a pending request
$pendingRequestCheckSQL = "SELECT * FROM requests WHERE user_id = $user_id AND consultant_id = $consultantId AND status = 'pending'";
$pendingRequestCheckResult = mysqli_query($conn, $pendingRequestCheckSQL);
$hasPendingRequest = mysqli_num_rows($pendingRequestCheckResult) > 0;

// Check if there is an active request
$activeRequestCheckSQL = "SELECT * FROM requests WHERE user_id = $user_id AND consultant_id = $consultantId AND status = 'active'";
$activeRequestCheckResult = mysqli_query($conn, $activeRequestCheckSQL);
$hasActiveRequest = mysqli_num_rows($activeRequestCheckResult) > 0;



?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mustashar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- Ajax -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="mustasharlogo.png" height="50px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="#" onclick="toggleAbout()">About/Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<!-- About Section -->
<div id="aboutSection" class="about-section">
    <div class="container mt-5">
      <h2 class="text-center mb-4">About Us</h2>
      <p class="lead">At Mustashar, we are more than just a consulting platform; we are a community dedicated to empowering developers
         at every stage of their journey. Our platform connects users with highly skilled consultants specializing in various software domains,
          including UX/UI design, requirement gathering, and quality assurance/control.
           We aim to provide a collaborative space where developers can seek guidance, share knowledge, and enhance their skills.
            Our commitment to fostering a vibrant ecosystem ensures that every developer has access to the expertise they need to 
            succeed in today's competitive landscape.</p>

      <h2 class="text-center mt-5 mb-4">Our Vision</h2>
      <p class="lead">We envision a future where every developer has seamless access to personalized consulting services that cater to their unique 
        challenges. Through Mustashar, we strive to break down barriers in the software development field, 
        enabling developers to connect with top-tier consultants effortlessly. 
        Our vision is to create an inclusive environment that promotes continuous learning, innovation, and collaboration. 
        By harnessing the collective knowledge and skills of our community, we aim to inspire developers to reach their 
        full potential and contribute meaningfully to the world of technology.</p>

      <h2 class="text-center mt-5 mb-4">Contact Us</h2>
      <p class="lead text-center">Email: <a href="mailto:abdulaziz.at00@gmail.com">abdulaziz.at00@gmail.com</a></p>
      <p class="lead text-center">WhatsApp: +966532606063</p>

      <div class="text-center">
        <p>Follow us:</p>
       <a href="#" class="text-white me-2"><i class="bi bi-facebook"></i></a>
       <a href="#" class="text-white me-2"><i class="bi bi-twitter"></i></a>
       <a href="#" class="text-white me-2"><i class="bi bi-linkedin"></i></a>
      </div>

      <div class="container text-center mt-5">
        <p class="lead">&copy; Mustashar 2024</p>
      </div>
    </div>
  </div>

  <script>
    function toggleAbout() {
      var aboutSection = document.getElementById('aboutSection');
      aboutSection.classList.toggle('show');
      var navbar = document.querySelector('.navbar');
      navbar.style.backgroundColor = aboutSection.classList.contains('show') ? '#343a40' : 'transparent'; // Change navbar background color based on section visibility
    }

  </script>

  <style>
    .navbar {
      transition: background-color 0.5s ease;
    }

    .about-section {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.5s ease;
      /* Smooth transition for max-height */
      background-color: #343a40;
      /* Match the background color of the navbar */
      color: #fff;
      /* Text color */
      padding: 20px;
    }

    .about-section.show {
      max-height: 1000px;
      /* Set to a large value to allow for dynamic content height */
    }
  </style>


<!-- Nav bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">&copy; Mustashar</a>
    <div class="navbar-nav ms-auto">
      <!-- Profile Section -->
      <a href="viewprofile.php">
        <img src="profile-icon.svg" alt="Profile Photo" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;">
      </a>
    </div>
  </div>
</nav>


<!-- Consultant Profile Section -->
<div class="container mt-5">
<div class="d-flex justify-content-end mb-2">
    <?php if ($hasPendingRequest): ?>
        <!-- If there is a pending request, disable the button -->
        <button class="btn btn-secondary" disabled>Request Sent</button>
    <?php elseif ($hasActiveRequest): ?>
        <!-- If there is an active request, show a green checkmark icon -->
        <i class="bi bi-check-circle text-success"></i> <!-- Green checkmark icon -->
        <span class="text-success">Active Request</span>
    <?php else: ?>
        <!-- If there are no requests, allow the user to send a new request -->
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#requestModal">Send Request</button>
    <?php endif; ?>
</div>


    <?php if (isset($first_name)): // Check if data is available ?>
    <div class="card">
        <div class="card-header">
            <h2 class="card-title text-center"><?= htmlspecialchars($first_name) . " " . htmlspecialchars($last_name); ?></h2>
            <h4 class="text-muted text-center"><?= htmlspecialchars($field); ?></h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>Email:</strong> <?= htmlspecialchars($email); ?></li>
                        <li class="list-group-item"><strong>Phone Number:</strong> <?= htmlspecialchars($phone_number); ?></li>
                        <li class="list-group-item"><strong>Age:</strong> <?= htmlspecialchars($age); ?></li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>Experience:</strong> <?= htmlspecialchars($experience); ?> years</li>
                        <li class="list-group-item"><strong>Bio:</strong> <?= nl2br(htmlspecialchars($bio)); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-warning text-center">No consultant details available.</div>
    <?php endif; ?>
</div>
<!-- Request Modal -->
<div class="modal fade" id="requestModal" tabindex="-1" aria-labelledby="requestModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="requestModalLabel">Send Request</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to send a request to this consultant?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="sendRequest()">Confirm</button>
            </div>
        </div>
    </div>
</div>

<script>
function sendRequest() {
    const consultantId = <?= htmlspecialchars($consultantId) ?>;
    const userId = <?= htmlspecialchars($_SESSION['user_id']) ?>;

    $.ajax({
        url: 'sendRequest.php',
        type: 'POST',
        data: {
            consultant_id: consultantId,
            user_id: userId
        },
        success: function(response) {
            const result = JSON.parse(response);
            if (result.success) {
                alert(result.success);
                $('#requestModal').modal('hide');
                location.reload();
            } else if (result.error) {
                alert(result.error);
            }
        },
        error: function() {
            alert("There was an error sending your request. Please try again.");
        }
    });
}

</script>










<!-- chatting interface under here-->




<!-- Chat Interface -->
<div id="chat-container" class="container my-4 p-3 border rounded shadow-sm">
  <div id="message-list" class="p-3 mb-3" style="height: 300px; overflow-y: auto; background-color: #f8f9fa; border-radius: 5px;">
    <!-- Messages will be displayed here -->
  </div>
  <div class="input-group">
    <input type="text" id="message-input" class="form-control" placeholder="Type your message...">
    <button id="send-button" class="btn btn-dark">Send</button>
  </div>
</div>

<!-- Custom Styling for Chat Interface -->
<style>
  #chat-container {
    max-width: 600px;
    background-color: #ffffff;
  }
  #message-list {
    background-color: #f8f9fa;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .message {
    margin-bottom: 10px;
    padding: 8px 12px;
    border-radius: 10px;
    max-width: 70%;
    word-wrap: break-word;
  }
  .message.sent {
    background-color: #d1e7dd; /* Light green for sent messages */
    text-align: right;
    margin-left: auto;
  }
  .message.received {
    background-color: #e2e3e5; /* Light gray for received messages */
    text-align: left;
    margin-right: auto;
  }
  #message-input {
    border-radius: 0; /* Sleek design */
  }
  #send-button {
    border-radius: 0; /* Match the input field */
  }
  .sender-name {
  font-weight: bold;
  display: block; /* Ensures the name is on its own line */
  margin-bottom: 2px; /* Adds a small space between the name and message */
}

.message-text {
  margin-left: 10px; /* Add a small indentation for the message */
}

</style>


<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-database.js"></script>

  <script>
    // Your Firebase configuration
    const firebaseConfig = {
      apiKey: "AIzaSyDldngosQltlHmvQvgaodrMmFuNURElTmw",
      authDomain: "mustashar-8866c.firebaseapp.com",
      projectId: "mustashar-8866c",
      storageBucket: "mustashar-8866c.appspot.com",
      messagingSenderId: "152444754973",
      appId: "1:152444754973:web:01fd8a4a4d4ba0825dfaf4",
      measurementId: "G-C9MWBJ4BNX"
    };

    // Initialize Firebase
    try {
      firebase.initializeApp(firebaseConfig);
      const database = firebase.database();
      // Your code to interact with Firebase Realtime Database goes here
    } catch (error) {
      console.error("Error initializing Firebase:", error);
      // Display an error message to the user
    }
  


  // Get references to the DOM elements
const messageList = document.getElementById('message-list');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');

// Get a reference to the Firebase Realtime Database
const database = firebase.database();
const messagesRef = database.ref('messages');

// Function to send a message


const username = "<?= htmlspecialchars($username); ?>";
const consultantID = "<?php echo $consultantId; ?>"; // Get consultant ID from PHP
const userID = "<?php echo $user_id; ?>"; // Get user ID from PHP

// Generate a unique chat room ID
const chatRoomID = `chat_${consultantID}_${userID}`;

// Get a reference to the specific chat room in Firebase
const chatRoomRef = firebase.database().ref(`chatRooms/${chatRoomID}`);


function sendMessage() {
  const messageText = messageInput.value;
  if (messageText.trim() !== '') {
    const newMessageRef = chatRoomRef.push(); // Push to the specific chat room
    newMessageRef.set({
      sender: `${username}`, // Use the actual sender's name
      message: messageText,
      timestamp: Date.now()
    });
    messageInput.value = ''; // Clear the input field
  }
}

// Function to append a message
function appendMessage(message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message');

  // Create a name element
  const nameElement = document.createElement('strong');
  nameElement.textContent = `${message.sender}`;
  nameElement.classList.add('sender-name');

  // Create a message text element
  const messageTextElement = document.createElement('div');
  messageTextElement.textContent = message.message;
  messageTextElement.classList.add('message-text');

  // Append name and message text to the message element
  messageElement.appendChild(nameElement);
  messageElement.appendChild(messageTextElement);

  // Add styling
  messageElement.classList.add('p-2', 'mb-2', 'rounded', 'bg-light', 'border');

  // Append the message element to the message list
  messageList.appendChild(messageElement);

  // Scroll to the bottom to show the latest message
  messageList.scrollTop = messageList.scrollHeight;
}



// Listen for new messages
chatRoomRef.on('child_added', (snapshot) => {
  const message = snapshot.val();
  appendMessage(message); // Append the new message
});



// Attach event listener to the send button
sendButton.addEventListener('click', sendMessage);

</script>



  <!-- Footer -->
<footer class="bg-secondary text-white mt-0">
  <div class="bg-dark text-center py-3">
    <p class="mb-0">&copy; Mustashar 2024. All Rights Reserved.</p>
  </div>
</footer>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>

</html>