
<div class="container mt-5">
  <h2 class="text-center mb-4">Real-Time Chat</h2>
  <div id="chat-box" class="border p-3 mb-3" style="height: 300px; overflow-y: scroll;"></div>
  <div class="input-group">
    <input type="text" id="message-input" class="form-control" placeholder="Type your message..." />
    <button class="btn btn-dark" onclick="sendMessage()">Send</button>
  </div>
</div>
