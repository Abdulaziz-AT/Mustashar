<?php
require 'database.php'; // Include your database connection

$user_id = $_POST['user_id'];
$consultant_id = $_POST['consultant_id'];

// Check if a request already exists
$requestCheckSQL = "SELECT * FROM requests WHERE user_id = $user_id AND consultant_id = $consultant_id AND status = 'pending'";
$requestCheckResult = mysqli_query($conn, $requestCheckSQL);

if (mysqli_num_rows($requestCheckResult) > 0) {
    echo json_encode(['error' => 'Request already exists.']);
} else {
    // Insert the new request
    $insertRequestSQL = "INSERT INTO requests (user_id, consultant_id, status) VALUES ($user_id, $consultant_id, 'pending')";
    if (mysqli_query($conn, $insertRequestSQL)) {
        echo json_encode(['success' => 'Request sent successfully.']);
    } else {
        echo json_encode(['error' => 'Failed to send request.']);
    }
}
?>
